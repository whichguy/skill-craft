```text
=== ShipLoop status ===
Where:     Release > system-test-author (1 of 9)
Run:       Preparation ✓ | Work items 1/1 ✓ | Release ▶
Stages:    system-test-author ▶ system-test · product-acceptance · release-plan · release-check · release · release-verify · operations · handoff ·
Done:      W1 carry-forward (reviewed by Improve): W1 is committed.
Next:      system-test-author: author the system tests
Completed: 1 item; W1 "Fix paginate() dropping the last partia…": W1 is committed
=== end ShipLoop status ===
```
