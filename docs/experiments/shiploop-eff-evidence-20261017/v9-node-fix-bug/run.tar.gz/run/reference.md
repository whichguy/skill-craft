<!-- shiploop-reference: 1.3.0 -->
# ShipLoop run reference

Run nav-051164f883014643914e6e8dfc7d8f55. Packets name a section as reference#<anchor>; open it only when the packet says to, or after a reset.

## Rules for every step {#rules}

This packet assigns one script-selected SDLC producer step.  The script owns the
durable graph, action identity, and legal successor; you own the engineering
judgment, repository work, evidence, and result. Perform only the current step
before its callback, then immediately follow the newly returned packet.
Preserve unrelated work and do not choose a successor, advance parent state
yourself, or treat a previous packet as the current assignment.

Use the Stage readiness and completion guide for this activity's Definition of
Ready (inputs and prerequisites) and Definition of Done (scoped output and due
evidence). Definition complete, tests planned, tests authored and tests passed
are different claims; retain later-phase verification without claiming it now.

Read the current repository, run state, applicable instructions, and relevant
durable lessons before relying on earlier notes.  Treat Git history, plans, tool
descriptions, and prior results as context to recheck, not authority or proof.
Use actual observations for test, build, integration, release, and consumer
claims.  Keep scope, target authority, artifact identity, operation effects, and
consumer behavior distinct.  A missing prerequisite, permission, access, or
trustworthy check is unresolved or blocked; it is not a successful N/A.
Blocked means work this stage cannot do: a missing target or account, a missing
approval, or a command with no replacement available inside the stage. A retained
command that does not run what it claims (for example a test path the runner does
not expand) is a documentation fix made in this stage, then rerun, not a blocker.
Write temporary files (command output, a report you pipe into a tool) in the
packet's Scratch directory, not /tmp: /tmp is shared with other runs and
sessions, and a fixed /tmp name can read another run's file.
ShipLoop runs unattended: no one is watching and nothing arrives on standard
input. When a decision is open, take the default that best fits the request and
the recorded knowledge, record it as an assumption (the alternatives and why
this one) in the result's summary (only plan's result has an assumptions list),
and continue. When a step can only be done by a person (a sign-in, a
grant, an observation in a signed-in browser), record it as an open item in the
result, with who must do what and what they should report, and continue with
everything that does not depend on it. Only when nothing further can proceed
without the person, report blocked with `blocked_by` user (or access, for a
sign-in) and `awaiting`: `{"kind": "answer", "question": "...", "options": [...], "no_default": "..."}`
for a decision, or `{"kind": "present", "steps": [...], "report": "...", "no_default": "..."}`
for something only a person can do; `no_default` says why no recorded default
would do, and ShipLoop refuses a wait without it. Ask one decision per question,
in words the user can answer in one reply. The run then stops until the user's
own reply resumes it.

For identity or access discovery, use supported non-mutating probes and
sanitized evidence. Normal supported tool-managed authentication and tool
configuration metadata without session material remain allowed. Builders and
reviewers must not read, decode, retain, or report local authentication,
session, or credential-store contents.

Requested runtime / entry point / material dependency: preserve each original
user requirement, and distinguish it from a verified contract, observed practice,
or assumption in the existing notes/results. Record local-test-route evidence
separately from target compatibility. A local fixture or preview cannot supply a
target capability absent from the requested runtime. Delivery outside the present
scope does not by itself make requested-runtime compatibility N/A. Establish
compatibility with target-compatible source or local evidence where possible;
otherwise keep the gap unresolved.

Follow the packet's Maintained requirements policy. Read the applicable accepted
product requirements, including preserved and cross-cutting conditions, from
their repository-owned home; a new request changes scope without erasing
unaffected rules. Carry requirement and test locators into work-item context.
Do not infer approved intent from code/tests or silently relax a condition to
match them. Keep proposals and verification gaps distinct from accepted intent.
Follow the packet's Reference handoff policy: distinguish package guidance,
repository-owned requirements/tests and run-local evidence. Resolve and verify
the selected file/section against its named root; retain exact applicable
locators for downstream work, not merely a link to this policy.
Use the packet's Requirements definition guide to reconcile existing specs and
define applicable non-functional requirements. Current explicit user instructions
supersede conflicting older clauses; preserve unaffected conditions and retain
clarification, requirement, and verification locators for cold recovery.
Later clarifications must be actual user instructions for this same request with
their durable user-source/decision basis; an unverified host summary is not an
instruction. Use the active correction/revision route for affected frozen contracts.

Return the packet's concise producer result with a truthful outcome, summary,
and useful evidence locators. For relevant product work, include the selected
maintained requirement sections and test/evidence locators in the result's
existing evidence_refs so a later reader can recover them. If a required
source is missing, report the gap rather than inventing a locator or omitting it.
A justified N/A is still an output that states
what was assessed and why it does not apply. ShipLoop starts an Improve child
after planning results (spec, test-strategy, plan, step-plan, test-spec,
system-test-author, release-plan), after each accepted implement step, and after
the carry-forward that leaves no work item pending. Run only the checks this step's change needs. When this step changes no
product file, its check is the named command, its exit code and its required output
substrings: record them, cite the earlier accepted stage that ran the same command,
and do not reread history to repeat it.

## Blocked, and waiting for a person {#blocked}

ShipLoop runs unattended: no one is watching and nothing arrives on standard input.
- An open decision: take the default that best fits the request and the recorded knowledge, record it as an
  assumption (the alternatives and why this one), and continue.
- A step only a person can do (a sign-in, a grant, an observation in a signed-in browser): record it as an open item
  in the result (who must do what, what they report back) and continue with everything that does not depend on it.
- Only when nothing further can proceed without the person: outcome `blocked` with `blocked_by` user (or access, for
  a sign-in) and `awaiting`, one decision per question, in words the user can answer in one reply:
  - a decision: `{"kind": "answer", "question": "...", "options": [...], "no_default": "..."}`
  - something only a person can do: `{"kind": "present", "steps": [...], "report": "...", "no_default": "..."}`
  `no_default` says why no recorded default would do; ShipLoop refuses a wait without it. The run then stops until
  the user's own reply resumes it.
- Blocked means work this stage cannot do (a missing target, account or approval, or a command with no replacement
  inside the stage). A retained command that does not run what it claims is a documentation fix made in this stage,
  then rerun, not a blocker. A problem this run can fix itself is repaired in this stage.

## Result outcomes {#outcomes}

The result file holds one `shiploop-state` block whose object has "outcome" and "summary" as top-level fields; do
not wrap it in action or result keys. An outcome other than done keeps headline and evidence_refs and drops the
done-only fields (work_items, assumptions, steps, test_commands, ...):
- repeat: {"outcome": "repeat", "summary": "<what is still open>"}
- blocked: {"outcome": "blocked", "blocked_by": "user | access | external", "summary": "<what stopped the work>"},
  plus "awaiting" only as described in reference#blocked
- revise: {"outcome": "revise", "summary": "<what in the step plan or test spec is wrong>"}: the item goes back to
  step-plan with this result as evidence
- replan (only where the packet allows it): {"outcome": "replan", "summary": "...", "work_items": [{"id": "...",
  "title": "...", "context": "..."}]}
A packet lists the outcomes its stage accepts; any other is refused.

## Recovery {#recovery}

After an interruption or a reset, run the packet's Recover command: it only reads the saved state and reprints the
current packet. Check the paths and the task and repository identity, then reconcile actual effects with the saved
history and relevant evidence before repeating work. If the same run cannot be located, keep recovery incomplete; do
not initialize a replacement or invent a callback. If paused or blocked, resolve the condition and follow the
printed resume route; if halted or done, stop. Keep the run directory and the Recover command in any durable handoff:
they locate state.md and store no other graph position.
Recover: python3 /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/scripts/shiploop next --run-dir=/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/run

## Progress reporting {#progress}

Progress: do not reprint this packet's ShipLoop status block; it orients you.
The user sees the run's status through a host status hook where one exists. At
start/recovery and after each callback, tell the user at most one line of your
own: the item, the stage just finished and the stage now starting. Show the whole
block unchanged only when the user asks for the full status. At milestones a packet
also carries a ShipLoop narrative section; follow its first line, which says whether
you paste the narrative to the user as written or the host already showed it. Only the current owner reports overall progress. State labels say which action is assigned, not that work, tests, or
Improve iterations have occurred.  Describe Improve activity only from its own
observed records; do not infer a review count, completion percentage, or ETA.
Run to completion by default within scope and authority. Emit progress as an
intermediate update, then immediately continue the active packet's current owner
while authorized runnable work remains. Do not wait for acknowledgement, ask
whether to continue, or end the turn merely to deliver a report. Follow the exact
callback and its returned packet, including a bound Improve child; a producer's
done or a child's completion is not run completion. Respect explicit user stops
and paused/blocked/halted/done states. A user message that asks to stop or pause,
or says not to implement, is a stop for product work: run the current packet's pause
command, answer it, and resume only on an explicit continue. A question or comment
about this skill, the loop, its progress or its cost is not a stop: answer it
briefly and keep following the current packet. Do not pause on your own to ask
whether the run is worth continuing or to confirm the process for a small task;
the user's request already authorizes the run. Never end the turn while a ShipLoop
command is still running: keep each one in the foreground until it returns, and if
the host moves it to a background task, wait for that task in this same turn before
anything else. A `complete` that reruns tests can take minutes, and a headless host
ends the whole session when the turn ends, losing the callback. If a host keepalive
hook refuses to end the turn, its reason names this run's next command: run it and
follow the packet. Resolve recoverable conditions through the
printed route and ask only for an actually missing decision, authority, or access.

## Requirements and references {#requirements}

Requested runtime / entry point / material dependency: preserve each original
user requirement, and distinguish it from a verified contract, observed practice,
or assumption in the existing notes/results. Record local-test-route evidence
separately from target compatibility. A local fixture or preview cannot supply a
target capability absent from the requested runtime. Delivery outside the present
scope does not by itself make requested-runtime compatibility N/A. Establish
compatibility with target-compatible source or local evidence where possible;
otherwise keep the gap unresolved.

Follow the packet's Maintained requirements policy. Read the applicable accepted
product requirements, including preserved and cross-cutting conditions, from
their repository-owned home; a new request changes scope without erasing
unaffected rules. Carry requirement and test locators into work-item context.
Do not infer approved intent from code/tests or silently relax a condition to
match them. Keep proposals and verification gaps distinct from accepted intent.
Follow the packet's Reference handoff policy: distinguish package guidance,
repository-owned requirements/tests and run-local evidence. Resolve and verify
the selected file/section against its named root; retain exact applicable
locators for downstream work, not merely a link to this policy.
Use the packet's Requirements definition guide to reconcile existing specs and
define applicable non-functional requirements. Current explicit user instructions
supersede conflicting older clauses; preserve unaffected conditions and retain
clarification, requirement, and verification locators for cold recovery.
Later clarifications must be actual user instructions for this same request with
their durable user-source/decision basis; an unverified host summary is not an
instruction. Use the active correction/revision route for affected frozen contracts.

## Policies and guides {#policies}

Each label is what a packet or stage text names; open only the section a step needs.
- Access-readiness policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/research-loop.md#early-access-readiness
- Delivery-authority policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/delivery-authority.md
- Environment lifecycle policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/environment-lifecycle.md
- Cross-run knowledge policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/project-knowledge.md
- Maintained requirements policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/project-knowledge.md#maintained-product-requirements
- Requirements definition guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/requirements-definition.md
- Stage readiness and completion guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/testing-and-documentation.md#stage-readiness-and-completion
- Initial repository baseline guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/execution-planning.md#initial-repository-baseline
- Reference handoff policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/project-knowledge.md#reference-handoffs-and-destinations
- Consumer testing guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/testing-and-documentation.md#lightweight-and-browser-checks
- Repeatable test-suite guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/repeatable-test-suites.md
- Selected-case reconciliation guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/testing-and-documentation.md#test-cases
- Real-boundary selection guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/testing-and-documentation.md#surface-selection
- Interaction design guide: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/behavioral-requirements.md#actors-channels-and-state-ownership
- Worktree and artifact policy: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/workspace-lifecycle.md
- Navigator contract: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/references/navigator.md
- Environment lifecycle note (host-authored, if present): /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/run/notes/environment-lifecycle.md
- Repository knowledge index (host-authored, if present): /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/worktree/SHIPLOOP.md
- ShipLoop skill card: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/shiploop/SKILL.md
- State: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/run/state.md · results: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/run/results · inbox: /private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/run/inbox

## Workspace and the source return {#workspace}

All product work happens in the execution checkout; run state, results and reports stay outside it. Each item is
assembled there, and ShipLoop commits its declared files when verify is accepted; the original branch is returned only
at release or handoff, after the assembled-candidate checks. There, `workspace plan-return` commits product files still uncommitted onto the
run branch (never run evidence, protected paths or files that look like credentials) and binds a path review;
decide every path with `workspace review-return --keep PATH... --exclude PATH...` (keep lasting work, exclude
transient output), then `workspace return`. The release packet prints the exact commands. No automatic push,
cleanup or publication is implied.
