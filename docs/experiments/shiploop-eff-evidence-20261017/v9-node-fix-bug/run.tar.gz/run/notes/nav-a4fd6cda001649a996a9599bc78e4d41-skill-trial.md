Skill trial: decision none. Single one-line fix, no repeated procedure; queue empty; R-3 recorded in HOME/spec.md.
