# ShipLoop navigator result

```shiploop-state
{
  "action": "nav-d934d06a082e4e958d8dab5fcc8acc2a",
  "navigator_protocol_version": 4,
  "result": {
    "evidence_refs": [],
    "outcome": "done",
    "summary": "Synthetic: recorded by the E2E seed without doing it; the request is the specification."
  },
  "run_id": "nav-051164f883014643914e6e8dfc7d8f55",
  "stage": "discovery",
  "workitem": null
}
```
