# ShipLoop standalone Improve receipt

```shiploop-state
{
  "action_id": "nav-a4fd6cda001649a996a9599bc78e4d41",
  "binding_id": "nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41",
  "evidence": [
    {
      "archive": "improve/nav-a4fd6cda001649a996a9599bc78e4d41/evidence/01-review-1.md",
      "sha256": "845ddc92106f66c6975e7a1a37580d7c826a081c42ec58e8b7b8a7f87b12f96f",
      "source": ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41/reviews/review-1.md"
    },
    {
      "archive": "improve/nav-a4fd6cda001649a996a9599bc78e4d41/evidence/02-checks.md",
      "sha256": "97d9ab19abce82d9c517121aaa7973356f271ea8176d1c89cdf90ab7da841f3b",
      "source": ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41/reviews/checks.md"
    }
  ],
  "identities": {
    "context_sha256": "28ece8740bd194fe2d434e923a507bea1bf59a2e6bbac5f9f57d19c9c58c0447",
    "evidence_sha256": {
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41/reviews/checks.md": "97d9ab19abce82d9c517121aaa7973356f271ea8176d1c89cdf90ab7da841f3b",
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41/reviews/review-1.md": "845ddc92106f66c6975e7a1a37580d7c826a081c42ec58e8b7b8a7f87b12f96f"
    },
    "last_report_sha256": "ef61fdba06b2098439348586f3dd2bb7b37226cfe32da13ad2569686fad38399",
    "terminal_packet_sha256": "14898e73fbfd33610c7883f869dead8f97a62c32455d3ccc326293eeeb8d043b"
  },
  "receipt": {
    "check_refs": [
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41/reviews/checks.md"
    ],
    "review_refs": [
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-a4fd6cda001649a996a9599bc78e4d41/reviews/review-1.md"
    ],
    "summary": "Improve reviewed the carry-forward result; it ended on 1 trivial pass."
  },
  "runtime_phase": "complete",
  "skill": {
    "runtime_card": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/runtime/until-loop/ADAPTER.md",
    "runtime_cli": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/runtime/until-loop/scripts/until_loop_ephemeral.py",
    "runtime_version": "0.8.3",
    "skill_card": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/SKILL.md",
    "skill_version": "0.4.1"
  },
  "stage": "carry-forward",
  "stale_check_note": "This import records a host-preserved structurally valid terminal Until Loop packet and current declared local evidence. It does not prove the packet was issued by the runtime, review or check claims, candidate scope, semantic Improve convergence, or future freshness; those remain the selected Improve skill and parent action's responsibility.",
  "version": 1,
  "workspace": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/worktree"
}
```
