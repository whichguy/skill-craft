npm test pass 8, fail 0 on committed tree
