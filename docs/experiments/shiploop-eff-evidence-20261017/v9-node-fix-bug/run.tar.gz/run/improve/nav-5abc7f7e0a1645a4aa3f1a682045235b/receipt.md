# ShipLoop standalone Improve receipt

```shiploop-state
{
  "action_id": "nav-5abc7f7e0a1645a4aa3f1a682045235b",
  "binding_id": "nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b",
  "evidence": [
    {
      "archive": "improve/nav-5abc7f7e0a1645a4aa3f1a682045235b/evidence/01-review-1.md",
      "sha256": "85d32dc268efad15638e3e32dd3773da5474bfc83940e1d764452feba78ac5a0",
      "source": ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b/reviews/review-1.md"
    },
    {
      "archive": "improve/nav-5abc7f7e0a1645a4aa3f1a682045235b/evidence/02-checks.md",
      "sha256": "f73c4ef12d1ec4d59e7d9bc90729a36e0cab149e0f852a2d4a4a501a90138f2d",
      "source": ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b/reviews/checks.md"
    }
  ],
  "identities": {
    "context_sha256": "92f3f7b7856ea001ca1c565bfe91ce56e4c4baa7baa567ae91acda9ba562746f",
    "evidence_sha256": {
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b/reviews/checks.md": "f73c4ef12d1ec4d59e7d9bc90729a36e0cab149e0f852a2d4a4a501a90138f2d",
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b/reviews/review-1.md": "85d32dc268efad15638e3e32dd3773da5474bfc83940e1d764452feba78ac5a0"
    },
    "last_report_sha256": "8c6b609488e4e992f21a78b6dca3c0d0755ffd0bd4993f2e188b21a71cc00006",
    "terminal_packet_sha256": "21f54551fc0b2b3a9e685eea5013f7a715b2860cd9cbe809b1e73946ddc58438"
  },
  "receipt": {
    "check_refs": [
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b/reviews/checks.md"
    ],
    "review_refs": [
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-5abc7f7e0a1645a4aa3f1a682045235b/reviews/review-1.md"
    ],
    "summary": "Improve reviewed the test-spec result; it ended on 1 trivial pass."
  },
  "runtime_phase": "complete",
  "skill": {
    "runtime_card": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/runtime/until-loop/ADAPTER.md",
    "runtime_cli": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/runtime/until-loop/scripts/until_loop_ephemeral.py",
    "runtime_version": "0.8.3",
    "skill_card": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/SKILL.md",
    "skill_version": "0.4.1"
  },
  "stage": "test-spec",
  "stale_check_note": "This import records a host-preserved structurally valid terminal Until Loop packet and current declared local evidence. It does not prove the packet was issued by the runtime, review or check claims, candidate scope, semantic Improve convergence, or future freshness; those remain the selected Improve skill and parent action's responsibility.",
  "version": 1,
  "workspace": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/worktree"
}
```
