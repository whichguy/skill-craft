complete --check-only for test-spec accepted; npm test passes 7/7 on base.
