npm test 7 pass; node --check ok; edge cases verified by node -e
