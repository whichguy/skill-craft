E1 broken-reproduces exit0, E2 exit0; npm test on base passes (existing tests only). check-only accepted.
