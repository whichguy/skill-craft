# ShipLoop standalone Improve receipt

```shiploop-state
{
  "action_id": "nav-3a28fd23340c4d02b25b75858c852abc",
  "binding_id": "nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc",
  "evidence": [
    {
      "archive": "improve/nav-3a28fd23340c4d02b25b75858c852abc/evidence/01-review-1.md",
      "sha256": "546691f89befd5f46fbc9a2688d2b84c80816cfa82486c05894b22851af19ae6",
      "source": ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc/reviews/review-1.md"
    },
    {
      "archive": "improve/nav-3a28fd23340c4d02b25b75858c852abc/evidence/02-checks.md",
      "sha256": "1911819b66e76b7d741efdc966507ea1ddd9c7c3119de57e7a8d2816f223e11f",
      "source": ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc/reviews/checks.md"
    }
  ],
  "identities": {
    "context_sha256": "aaa7f1b55eafd88c61f5619423dd4a0bdd2c0614d6e9fb5f0530b333373eccf2",
    "evidence_sha256": {
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc/reviews/checks.md": "1911819b66e76b7d741efdc966507ea1ddd9c7c3119de57e7a8d2816f223e11f",
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc/reviews/review-1.md": "546691f89befd5f46fbc9a2688d2b84c80816cfa82486c05894b22851af19ae6"
    },
    "last_report_sha256": "fddf3a8e403e9f5d43d03da77eb8ceceb51d8743cdd5d83a3ab37361d608f9e0",
    "terminal_packet_sha256": "04beef60964911f20a93293d9293caa6bb69ade29a0eb207f6053302d81d95a9"
  },
  "receipt": {
    "check_refs": [
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc/reviews/checks.md"
    ],
    "review_refs": [
      ".shiploop-improve/nav-051164f883014643914e6e8dfc7d8f55/nav-3a28fd23340c4d02b25b75858c852abc/reviews/review-1.md"
    ],
    "summary": "Improve reviewed the step-plan result; it ended on 1 trivial pass."
  },
  "runtime_phase": "complete",
  "skill": {
    "runtime_card": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/runtime/until-loop/ADAPTER.md",
    "runtime_cli": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/runtime/until-loop/scripts/until_loop_ephemeral.py",
    "runtime_version": "0.8.3",
    "skill_card": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/build/plugins/skill-craft/skills/improve/SKILL.md",
    "skill_version": "0.4.1"
  },
  "stage": "step-plan",
  "stale_check_note": "This import records a host-preserved structurally valid terminal Until Loop packet and current declared local evidence. It does not prove the packet was issued by the runtime, review or check claims, candidate scope, semantic Improve convergence, or future freshness; those remain the selected Improve skill and parent action's responsibility.",
  "version": 1,
  "workspace": "/private/tmp/claude-501/-Users-dadleet-src-skill-craft/8acf399b-0cf4-40cc-bba3-bf238461db58/scratchpad/v9/node-fix-bug/.shiploop-runs/seed/worktree"
}
```
